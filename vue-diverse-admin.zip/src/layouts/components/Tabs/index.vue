<template>
  <div class="tabs-box">
    <div class="tabs-menu">
      <el-tabs v-model="tabsMenuValue" type="card" class="demo-tabs" @tabClick="tabClick" @tabRemove="tabRemove">
        <el-tab-pane
          v-for="item in tabsMenuList"
          :key="item.fullPath"
          :label="item.title"
          :name="item.fullPath"
          :closable="item.close"
        >
          <template #label>
            <el-icon class="tabs-icon" v-if="item.icon && themeConfig.tabsIcon">
              <component :is="item.icon"></component>
            </el-icon>
            {{ item.title }}
          </template>
        </el-tab-pane>
      </el-tabs>
      <MoreButton />
    </div>
  </div>
</template>

<script setup>
import Sortable from "sortablejs";
import { ref, computed, watch, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";
import { GlobalStore } from "@/stores";
import { TabsStore } from "@/stores/modules/tabs";
import { AuthStore } from "@/stores/modules/auth";
import { KeepAliveStore } from "@/stores/modules/keepAlive";
import MoreButton from "./components/MoreButton.vue";

const route = useRoute();
const router = useRouter();
const tabStore = TabsStore();
const globalStore = GlobalStore();
const authStore = AuthStore();
const keepAliveStore = KeepAliveStore();

const tabsMenuValue = ref(route.fullPath);
const tabsMenuList = computed(() => tabStore.tabsMenuList);
const themeConfig = computed(() => globalStore.themeConfig);

onMounted(() => {
  tabsDrop();
  initTabs();
});

// 标签拖拽排序
const tabsDrop = () => {
  Sortable.create(document.querySelector(".el-tabs__nav"), {
    draggable: ".el-tabs__item",
    animation: 300,
    onEnd({ newIndex, oldIndex }) {
      const tabsList = [...tabStore.tabsMenuList];
      const currRow = tabsList.splice(oldIndex, 1)[0];
      tabsList.splice(newIndex, 0, currRow);
      tabStore.setTabs(tabsList);
    }
  });
};

// 初始化需要固定的标签
const initTabs = () => {
  authStore.flatMenuListGet.forEach(item => {
    if (item.meta.isAffix && !item.meta.isHide && !item.meta.isFull) {
      const tabsParams = {
        icon: item.meta.icon,
        title: item.meta.title,
        path: item.path,
        fullPath: item.fullPath,
        name: item.name,
        close: !item.meta.isAffix
      };
      tabStore.addTabs(tabsParams);
    }
  });
};

// 监听路由的变化（防止浏览器后退/前进不变化 tabsMenuValue）
watch(
  () => route.path,
  () => {
    if (route.meta.isFull) return;
    tabsMenuValue.value = route.fullPath;
    const tabsParams = {
      icon: route.meta.icon,
      title: route.meta.title,
      path: route.path,
      fullPath: route.fullPath,
      name: route.name,
      close: !route.meta.isAffix
    };
    tabStore.addTabs(tabsParams);
    // 当query变化时，更新tabsMenuList
    tabStore.updateTabs(route);
    route.meta.isKeepAlive && keepAliveStore.addKeepLiveName(route.name);
  },
  {
    immediate: true,
    deep: true
  }
);

// Tab Click
const tabClick = tabItem => {
  const fullPath = tabItem.props.name;
  router.push(fullPath);
};

// Remove Tab
const tabRemove = path => {
  const name = tabStore.tabsMenuList.filter(item => item.fullPath == path)[0]?.name || "";
  keepAliveStore.removeKeepLiveName(name);
  tabStore.removeTabs(path, path == route.fullPath);
};
</script>

<style scoped lang="scss">
@import "./index.scss";
.el-tabs__nav .el-tabs__item:nth-child(1) span {
  display: none;
}
</style>
