<template>
  <div class="footer flx-center">
    <a href="https://github.com/1164095457/vue-diverse-admin" target="_blank"> @2023{{ APP_NAME }} </a>
  </div>
</template>
<script setup>
import { APP_NAME } from "@/config/config";
</script>

<style scoped lang="scss">
@import "./index.scss";
</style>
