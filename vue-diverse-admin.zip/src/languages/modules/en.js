export default {
	test: {
		name: "English"
	}
};
