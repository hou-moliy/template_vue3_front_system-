export default {
	test: {
		name: "中文"
	}
};
