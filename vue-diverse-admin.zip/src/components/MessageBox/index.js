import MessageBox from "./src/index";

export { MessageBox };
