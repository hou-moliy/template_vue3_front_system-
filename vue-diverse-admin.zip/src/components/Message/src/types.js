export default {
  SUCCESS: "success",
  WARNING: "warning",
  MESSAGE: "message",
  ERROR: "error"
};
