import LockScreen from "./src/index";

export { LockScreen };
