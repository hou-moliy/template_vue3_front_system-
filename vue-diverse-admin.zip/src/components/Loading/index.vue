<template>
	<div class="loading-box">
		<div class="loading-wrap">
			<span class="dot dot-spin"><i></i><i></i><i></i><i></i></span>
		</div>
	</div>
</template>

<style scoped lang="scss">
@import "./index.scss";
</style>
