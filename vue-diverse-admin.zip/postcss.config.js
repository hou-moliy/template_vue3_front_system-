module.exports = {
	plugins: {
		autoprefixer: {}
	}
};
